﻿using GIF2SVG;

new Main();